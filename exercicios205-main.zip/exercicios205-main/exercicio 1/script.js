console.log("hello world");

window.prompt("hello world");